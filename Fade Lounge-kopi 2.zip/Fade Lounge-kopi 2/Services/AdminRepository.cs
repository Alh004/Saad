using Fade_Lounge.Model;
using Fade_Lounge.Pages.admin;
using Fade_Lounge.ServicAs;

namespace Fade_Lounge.Services;

public class AdminRepository: IAdminRepository
{   
    // instans felt
    private List<Admin> _katalogAdmin = new List<Admin>();
    
    public Admin? AdminLoggedIn { get; private set; }

    public AdminRepository(bool mockData = false)
    {
        AdminLoggedIn = null;

        if (mockData)
        {
            _katalogAdmin.Add(new Admin(1, "saad", "42546563", "hsfh@live.dk", "2000", true));
            _katalogAdmin.Add(new Admin(2, "saaad", "98234576", "yhbh@gmail.com", "2450", false));
            _katalogAdmin.Add(new Admin(3, "ok", "12456587", "peop@outlook.gb", "4312", true));
        }
    }
    

    public void AddKundeAdm(Admin admin)
    { 
        _katalogAdmin.Add(admin);
    }
    
    public bool CheckKundeAdm(string email, string adgangskode)
    {
        Admin? foundUser = _katalogAdmin.Find(u => u.Email1 == email && u.Adgangskode1 == adgangskode);

        if (foundUser != null)
        {
            AdminLoggedIn = foundUser;
            return true;
        }
        else
        {
            return false;
        }    
    }

    public void LogoutKundeAdm()
    {
        AdminLoggedIn = null;
    }

    public void RemoveKundeAdm(Admin admin)
    {
        _katalogAdmin.Remove(admin);
    }
    

    public Admin RemoveKundeAdm(int kundeNummer)
    {
        throw new NotImplementedException();
    }

    public Admin HentKunde(int kundeNummer)
    {
        throw new NotImplementedException();
    }
}

