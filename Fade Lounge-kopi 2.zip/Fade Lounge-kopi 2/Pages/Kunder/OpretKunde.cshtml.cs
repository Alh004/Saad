using System.ComponentModel.DataAnnotations;
using Fade_Lounge.Model;
using Fade_Lounge.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fade_Lounge.Pages.Kunder;


public class OpretNyKunde : PageModel
{
    private IKundeRepository _repo;

    public OpretNyKunde (IKundeRepository repo)
    {
        _repo = repo;
    }

    [BindProperty]
    public int NytKundeNummer { get; set; }


    [BindProperty]
    [Required(ErrorMessage = "Der skal være et navn")]
    [StringLength(100, MinimumLength = 2, ErrorMessage = "Der skal være mindst to tegn i et navn")]
    public string NytKundeNavn { get; set; }



    [BindProperty]
    [Required(ErrorMessage = "Der skal være et Nummer")]
    [StringLength(8, MinimumLength = 8, ErrorMessage = "Der skal være mindst otte tal i et nummer")]
    public string NytKundetlf { get; set; }
        
    [BindProperty]
    public string NyKundeEmail { get; set; }
        
        
    public string ErrorMessage { get; private set; }
    public bool Error { get; private set; }

    public void OnGet()
    {
        // If you need to perform any actions when the page is loaded, you can include them here.
    }

    public IActionResult OnPost()
    {
        ErrorMessage = "";
        if (!ModelState.IsValid)
        {
            return Page();
        }

        Kunde NyKunde1 = new Kunde(NytKundeNummer, NytKundeNavn,NytKundetlf, NyKundeEmail);

        try
        {
            _repo.AddKunde(NyKunde1);
        }
        catch (ArgumentException ae)
        {
            ErrorMessage = ae.Message;
            return Page();
        }

        return RedirectToPage("Index");
    }

    public IActionResult OnPostCancel()
    {
        return RedirectToPage("Index");
    }
}




